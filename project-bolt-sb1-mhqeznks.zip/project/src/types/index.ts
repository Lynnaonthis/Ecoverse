export interface User {
  id: string;
  username: string;
  email: string;
  level: number;
  xp: number;
  ecoCredits: number;
  treesPlanted: number;
  co2Offset: number;
  waterSaved: number;
  avatar: string;
  joinedAt: string;
  streak: number;
  rank: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: 'planting' | 'conservation' | 'cleanup' | 'education' | 'energy';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  xpReward: number;
  ecoCredits: number;
  duration: string;
  requirements: string[];
  progress: number;
  maxProgress: number;
  status: 'available' | 'in-progress' | 'completed';
  deadline?: string;
  location?: string;
  image: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  unlockedAt?: string;
  progress: number;
  maxProgress: number;
  requirement: string;
}

export interface LeaderboardEntry {
  rank: number;
  user: {
    username: string;
    avatar: string;
    level: number;
  };
  xp: number;
  treesPlanted: number;
  co2Offset: number;
}