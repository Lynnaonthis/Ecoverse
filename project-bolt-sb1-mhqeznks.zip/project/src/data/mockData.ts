import { User, Mission, Badge, LeaderboardEntry } from '../types';

export const mockUser: User = {
  id: '1',
  username: 'EcoWarrior',
  email: 'eco@example.com',
  level: 12,
  xp: 2450,
  ecoCredits: 1250,
  treesPlanted: 47,
  co2Offset: 1200,
  waterSaved: 3400,
  avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
  joinedAt: '2024-01-15',
  streak: 23,
  rank: 8
};

export const mockMissions: Mission[] = [
  {
    id: '1',
    title: 'Urban Forest Initiative',
    description: 'Plant 5 trees in your local urban area to help combat air pollution and create green corridors.',
    category: 'planting',
    difficulty: 'intermediate',
    xpReward: 150,
    ecoCredits: 75,
    duration: '2 weeks',
    requirements: ['Location permit', 'Saplings', 'Basic tools'],
    progress: 2,
    maxProgress: 5,
    status: 'in-progress',
    deadline: '2024-02-15',
    location: 'Downtown Park',
    image: 'https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  },
  {
    id: '2',
    title: 'Beach Cleanup Challenge',
    description: 'Remove 50 pounds of waste from coastal areas to protect marine ecosystems.',
    category: 'cleanup',
    difficulty: 'beginner',
    xpReward: 100,
    ecoCredits: 50,
    duration: '1 day',
    requirements: ['Cleanup bags', 'Gloves', 'Transportation'],
    progress: 0,
    maxProgress: 50,
    status: 'available',
    location: 'Sunset Beach',
    image: 'https://images.pexels.com/photos/1029604/pexels-photo-1029604.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  },
  {
    id: '3',
    title: 'Solar Panel Installation',
    description: 'Install renewable energy systems to reduce carbon footprint by 500kg CO2 annually.',
    category: 'energy',
    difficulty: 'advanced',
    xpReward: 300,
    ecoCredits: 200,
    duration: '1 month',
    requirements: ['Technical training', 'Equipment', 'Professional certification'],
    progress: 0,
    maxProgress: 1,
    status: 'available',
    image: 'https://images.pexels.com/photos/9875441/pexels-photo-9875441.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  },
  {
    id: '4',
    title: 'Wildlife Habitat Restoration',
    description: 'Create and maintain habitats for local wildlife species in degraded areas.',
    category: 'conservation',
    difficulty: 'intermediate',
    xpReward: 200,
    ecoCredits: 100,
    duration: '3 weeks',
    requirements: ['Native plant species', 'Habitat knowledge', 'Monitoring equipment'],
    progress: 1,
    maxProgress: 3,
    status: 'in-progress',
    image: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  },
  {
    id: '5',
    title: 'Community Education Workshop',
    description: 'Organize workshops to educate 100 community members about sustainable practices.',
    category: 'education',
    difficulty: 'intermediate',
    xpReward: 180,
    ecoCredits: 90,
    duration: '2 weeks',
    requirements: ['Presentation materials', 'Venue', 'Expert speakers'],
    progress: 25,
    maxProgress: 100,
    status: 'in-progress',
    image: 'https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  },
  {
    id: '6',
    title: 'Water Conservation System',
    description: 'Install rainwater harvesting systems to save 1000 gallons of water monthly.',
    category: 'conservation',
    difficulty: 'advanced',
    xpReward: 250,
    ecoCredits: 150,
    duration: '3 weeks',
    requirements: ['Plumbing knowledge', 'Installation materials', 'Permits'],
    progress: 0,
    maxProgress: 1000,
    status: 'available',
    image: 'https://images.pexels.com/photos/1112048/pexels-photo-1112048.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&dpr=1'
  }
];

export const mockBadges: Badge[] = [
  {
    id: '1',
    title: 'Tree Hugger',
    description: 'Plant your first tree',
    icon: 'Tree',
    category: 'Planting',
    rarity: 'common',
    unlocked: true,
    unlockedAt: '2024-01-20',
    progress: 1,
    maxProgress: 1,
    requirement: 'Plant 1 tree'
  },
  {
    id: '2',
    title: 'Forest Guardian',
    description: 'Plant 25 trees',
    icon: 'TreePine',
    category: 'Planting',
    rarity: 'rare',
    unlocked: true,
    unlockedAt: '2024-02-01',
    progress: 25,
    maxProgress: 25,
    requirement: 'Plant 25 trees'
  },
  {
    id: '3',
    title: 'Climate Champion',
    description: 'Offset 1000kg of CO2',
    icon: 'Cloud',
    category: 'Climate',
    rarity: 'epic',
    unlocked: true,
    unlockedAt: '2024-02-05',
    progress: 1200,
    maxProgress: 1000,
    requirement: 'Offset 1000kg CO2'
  },
  {
    id: '4',
    title: 'Ocean Protector',
    description: 'Remove 100 pounds of ocean waste',
    icon: 'Waves',
    category: 'Cleanup',
    rarity: 'rare',
    unlocked: false,
    progress: 65,
    maxProgress: 100,
    requirement: 'Remove 100 pounds of ocean waste'
  },
  {
    id: '5',
    title: 'Renewable Energy Pioneer',
    description: 'Install solar panels generating 1000kWh annually',
    icon: 'Sun',
    category: 'Energy',
    rarity: 'legendary',
    unlocked: false,
    progress: 0,
    maxProgress: 1000,
    requirement: 'Generate 1000kWh renewable energy'
  },
  {
    id: '6',
    title: 'Water Warrior',
    description: 'Save 5000 gallons of water',
    icon: 'Droplet',
    category: 'Conservation',
    rarity: 'epic',
    unlocked: false,
    progress: 3400,
    maxProgress: 5000,
    requirement: 'Save 5000 gallons of water'
  },
  {
    id: '7',
    title: 'Community Leader',
    description: 'Educate 500 people about sustainability',
    icon: 'Users',
    category: 'Education',
    rarity: 'legendary',
    unlocked: false,
    progress: 125,
    maxProgress: 500,
    requirement: 'Educate 500 people'
  },
  {
    id: '8',
    title: 'Streak Master',
    description: 'Maintain a 30-day activity streak',
    icon: 'Flame',
    category: 'Dedication',
    rarity: 'rare',
    unlocked: false,
    progress: 23,
    maxProgress: 30,
    requirement: 'Maintain 30-day streak'
  }
];

export const mockLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    user: {
      username: 'GreenMaster',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 28
    },
    xp: 8450,
    treesPlanted: 156,
    co2Offset: 4200
  },
  {
    rank: 2,
    user: {
      username: 'EcoHero',
      avatar: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 25
    },
    xp: 7200,
    treesPlanted: 134,
    co2Offset: 3800
  },
  {
    rank: 3,
    user: {
      username: 'PlanetSaver',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 22
    },
    xp: 6800,
    treesPlanted: 128,
    co2Offset: 3500
  },
  {
    rank: 4,
    user: {
      username: 'NatureNinja',
      avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 19
    },
    xp: 5900,
    treesPlanted: 112,
    co2Offset: 3100
  },
  {
    rank: 5,
    user: {
      username: 'ClimateGuard',
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 18
    },
    xp: 5200,
    treesPlanted: 98,
    co2Offset: 2900
  },
  {
    rank: 6,
    user: {
      username: 'ForestFriend',
      avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 16
    },
    xp: 4800,
    treesPlanted: 89,
    co2Offset: 2600
  },
  {
    rank: 7,
    user: {
      username: 'GreenThumb',
      avatar: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 15
    },
    xp: 4200,
    treesPlanted: 76,
    co2Offset: 2200
  },
  {
    rank: 8,
    user: {
      username: 'EcoWarrior',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 12
    },
    xp: 2450,
    treesPlanted: 47,
    co2Offset: 1200
  },
  {
    rank: 9,
    user: {
      username: 'SustainableSam',
      avatar: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 11
    },
    xp: 2100,
    treesPlanted: 38,
    co2Offset: 980
  },
  {
    rank: 10,
    user: {
      username: 'EarthAdvocate',
      avatar: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      level: 10
    },
    xp: 1800,
    treesPlanted: 32,
    co2Offset: 850
  }
];