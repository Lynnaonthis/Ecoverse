import React, { useState } from 'react';
import { Trophy, Medal, Award, TrendingUp, TreePine, Wind } from 'lucide-react';
import { mockLeaderboard, mockUser } from '../data/mockData';

const Leaderboard: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<string>('xp');

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-sm font-medium text-gray-600">
          {rank}
        </div>;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500';
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600';
      default:
        return 'bg-gradient-to-r from-gray-200 to-gray-300';
    }
  };

  const getMetricValue = (entry: any, metric: string) => {
    switch (metric) {
      case 'xp':
        return entry.xp.toLocaleString();
      case 'trees':
        return entry.treesPlanted.toLocaleString();
      case 'co2':
        return `${entry.co2Offset.toLocaleString()} kg`;
      default:
        return entry.xp.toLocaleString();
    }
  };

  const getMetricLabel = (metric: string) => {
    switch (metric) {
      case 'xp':
        return 'Experience Points';
      case 'trees':
        return 'Trees Planted';
      case 'co2':
        return 'CO2 Offset';
      default:
        return 'Experience Points';
    }
  };

  const getMetricIcon = (metric: string) => {
    switch (metric) {
      case 'xp':
        return <TrendingUp className="w-4 h-4" />;
      case 'trees':
        return <TreePine className="w-4 h-4" />;
      case 'co2':
        return <Wind className="w-4 h-4" />;
      default:
        return <TrendingUp className="w-4 h-4" />;
    }
  };

  const currentUserRank = mockLeaderboard.find(entry => entry.user.username === mockUser.username);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Global Leaderboard</h2>
        <p className="text-gray-600">See how you rank against other eco-warriors worldwide</p>
      </div>

      {/* Current User Stats */}
      {currentUserRank && (
        <div className="bg-gradient-to-r from-green-500 to-blue-500 rounded-xl p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img 
                src={currentUserRank.user.avatar} 
                alt={currentUserRank.user.username}
                className="w-16 h-16 rounded-full border-4 border-white shadow-lg"
              />
              <div>
                <h3 className="text-xl font-bold">{currentUserRank.user.username}</h3>
                <p className="text-green-100">Level {currentUserRank.user.level}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">#{currentUserRank.rank}</div>
              <div className="text-green-100">Global Rank</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <div className="text-2xl font-bold">{currentUserRank.xp.toLocaleString()}</div>
              <div className="text-green-100 text-sm">Total XP</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{currentUserRank.treesPlanted}</div>
              <div className="text-green-100 text-sm">Trees Planted</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{currentUserRank.co2Offset.toLocaleString()}</div>
              <div className="text-green-100 text-sm">CO2 Offset (kg)</div>
            </div>
          </div>
        </div>
      )}

      {/* Metric Selector */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex items-center space-x-4 mb-4">
          <TrendingUp className="w-5 h-5 text-gray-400" />
          <span className="font-medium text-gray-700">Ranking Metric</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {['xp', 'trees', 'co2'].map((metric) => (
            <button
              key={metric}
              onClick={() => setSelectedMetric(metric)}
              className={`p-4 rounded-lg border-2 transition-all ${
                selectedMetric === metric
                  ? 'border-green-500 bg-green-50 text-green-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                {getMetricIcon(metric)}
                <span className="font-medium">{getMetricLabel(metric)}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Leaderboard */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Trophy className="w-5 h-5 text-yellow-500 mr-2" />
            Top Environmental Champions
          </h3>
        </div>
        
        <div className="divide-y divide-gray-200">
          {mockLeaderboard.map((entry) => (
            <div 
              key={entry.rank} 
              className={`p-6 hover:bg-gray-50 transition-colors ${
                entry.user.username === mockUser.username ? 'bg-green-50 border-l-4 border-green-500' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-3">
                    {getRankIcon(entry.rank)}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${getRankBadgeColor(entry.rank)}`}>
                      {entry.rank}
                    </div>
                  </div>
                  
                  <img 
                    src={entry.user.avatar} 
                    alt={entry.user.username}
                    className="w-12 h-12 rounded-full border-2 border-gray-200"
                  />
                  
                  <div>
                    <h4 className="font-medium text-gray-900">{entry.user.username}</h4>
                    <p className="text-sm text-gray-500">Level {entry.user.level}</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-lg font-bold text-gray-900">
                    {getMetricValue(entry, selectedMetric)}
                  </div>
                  <div className="text-sm text-gray-500">
                    {getMetricLabel(selectedMetric)}
                  </div>
                </div>
              </div>
              
              {/* Additional stats for top 3 */}
              {entry.rank <= 3 && (
                <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-sm font-medium text-gray-900">{entry.xp.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">XP</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-sm font-medium text-gray-900">{entry.treesPlanted}</div>
                    <div className="text-xs text-gray-500">Trees</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-sm font-medium text-gray-900">{entry.co2Offset.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">CO2 (kg)</div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;