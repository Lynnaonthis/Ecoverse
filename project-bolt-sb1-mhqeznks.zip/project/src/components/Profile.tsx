import React from 'react';
import { Edit, Calendar, MapPin, Mail, Award, TrendingUp, TreePine, Wind, Droplet, Zap } from 'lucide-react';
import { mockUser, mockBadges } from '../data/mockData';

const Profile: React.FC = () => {
  const unlockedBadges = mockBadges.filter(badge => badge.unlocked);
  const nextLevelXP = (mockUser.level + 1) * 250;
  const xpProgress = (mockUser.xp % 250) / 250 * 100;

  const achievements = [
    {
      label: 'Trees Planted',
      value: mockUser.treesPlanted,
      icon: TreePine,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: 'CO2 Offset (kg)',
      value: mockUser.co2Offset.toLocaleString(),
      icon: Wind,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      label: 'Water Saved (L)',
      value: mockUser.waterSaved.toLocaleString(),
      icon: Droplet,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-100'
    },
    {
      label: 'Eco Credits',
      value: mockUser.ecoCredits.toLocaleString(),
      icon: Zap,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Profile</h2>
        <p className="text-gray-600">Manage your account and track your environmental impact</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Info */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="text-center mb-6">
              <div className="relative inline-block">
                <img 
                  src={mockUser.avatar} 
                  alt={mockUser.username}
                  className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-white shadow-lg"
                />
                <button className="absolute bottom-0 right-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white hover:bg-green-600 transition-colors">
                  <Edit size={16} />
                </button>
              </div>
              <h3 className="text-xl font-bold text-gray-900">{mockUser.username}</h3>
              <p className="text-gray-600">Level {mockUser.level} Eco-Warrior</p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex items-center space-x-3 text-gray-600">
                <Mail className="w-5 h-5" />
                <span>{mockUser.email}</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-600">
                <Calendar className="w-5 h-5" />
                <span>Joined {new Date(mockUser.joinedAt).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-600">
                <MapPin className="w-5 h-5" />
                <span>Global Rank #{mockUser.rank}</span>
              </div>
            </div>

            <button className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
              Edit Profile
            </button>
          </div>

          {/* Level Progress */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mt-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-gray-900">Level Progress</h4>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Level {mockUser.level}</span>
                <span>Level {mockUser.level + 1}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${xpProgress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{mockUser.xp} XP</span>
                <span>{nextLevelXP} XP</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-orange-50 rounded-lg p-3 text-center">
                <div className="text-xl font-bold text-orange-600">{mockUser.streak}</div>
                <div className="text-sm text-gray-600">Day Streak</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-3 text-center">
                <div className="text-xl font-bold text-purple-600">{unlockedBadges.length}</div>
                <div className="text-sm text-gray-600">Badges</div>
              </div>
            </div>
          </div>
        </div>

        {/* Achievements and Stats */}
        <div className="lg:col-span-2">
          {/* Environmental Impact */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-6">Environmental Impact</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                return (
                  <div key={index} className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${achievement.bgColor}`}>
                      <Icon className={`w-6 h-6 ${achievement.color}`} />
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-gray-900">{achievement.value}</div>
                      <div className="text-sm text-gray-600">{achievement.label}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Badges */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-lg font-semibold text-gray-900">Recent Badges</h4>
              <Award className="w-5 h-5 text-yellow-500" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {unlockedBadges.slice(0, 4).map((badge) => (
                <div key={badge.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{badge.title}</div>
                    <div className="text-sm text-gray-600">{badge.category}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;